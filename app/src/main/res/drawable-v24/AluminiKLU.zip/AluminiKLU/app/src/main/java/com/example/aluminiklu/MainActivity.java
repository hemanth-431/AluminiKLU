package com.example.aluminiklu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Spinner branch,course,specialisation,date,date1;
    private static final String[] COUNTRIES = new String[]{
            "Afghanistan", "Albania", "Algeria", "Andorra", "Angola"
    };

    private static final String[] Entry1 = new String[]{
            "1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000"
    };

    private static final String[] graduation1 = new String[]{
            "1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000"
    };
    private static final String[] Branch1= new String[]{
            "CSE", "ECE", "BBA", "CIVIL", "MEC"
    };
    private static final String[] course1 = new String[]{
            "B.Tech", "B.Arch", "M.B.A", "M.Tech", "Diploma"
    };
    private static final String[] specialization1 = new String[]{
            "ComputerNetworks", "I.O.T", "AI", "Ds", "BigData"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
button=findViewById(R.id.button3);
specialisation=findViewById(R.id.specialisation);
date=findViewById(R.id.date);
date1=findViewById(R.id.date1);
branch=findViewById(R.id.branch);
course=findViewById(R.id.course);
        String[] countries = getResources().getStringArray(R.array.countries);
        AutoCompleteTextView editText = findViewById(R.id.actv);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.custom_list_item, R.id.text_view_list_item, COUNTRIES);
        editText.setAdapter(adapter);


        ArrayAdapter<String> adapter1= new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, specialization1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        specialisation.setAdapter(adapter1);


        ArrayAdapter<String> adapter6 = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,Entry1);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        date.setAdapter(adapter6);

        ArrayAdapter<String> adapter7 = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,graduation1);
        adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       date1.setAdapter(adapter7);

        ArrayAdapter<String> adapter4 = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,Branch1);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        branch.setAdapter(adapter4);


        ArrayAdapter<String> adapter5 = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1,course1);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        course.setAdapter(adapter5);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,home.class);
                startActivity(i);
            }
        });
    }


}
