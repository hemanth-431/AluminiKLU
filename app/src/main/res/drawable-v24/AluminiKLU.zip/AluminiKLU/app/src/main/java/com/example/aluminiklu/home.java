package com.example.aluminiklu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class home extends AppCompatActivity {
    ListView my;
    ArrayList<Integer> array = new ArrayList<Integer>();

  private   Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        spinner = findViewById(R.id.spinner);
        for(int i=1990;i<=2018;i++)
        {
array.add(i);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter(home.this, android.R.layout.simple_list_item_1, array);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
}
